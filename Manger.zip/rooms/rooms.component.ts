// import { Component } from '@angular/core';

// @Component({
//   selector: 'app-rooms',
//   imports: [],
//   templateUrl: './rooms.component.html',
//   styleUrl: './rooms.component.css'
// })
// export class RoomsComponent {

// }
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common'; // For NgIf and NgFor
import { FormsModule } from '@angular/forms'; // For [(ngModel)]

interface Room {
  roomNo: string;
  type: string;
  status: 'Available' | 'Occupied' | 'Maintenance';
  price: number;
}

@Component({
  selector: 'app-room-management',
  standalone: true,
  imports: [CommonModule, FormsModule], // Import CommonModule for NgIf/NgFor and FormsModule for ngModel
  templateUrl: './room-management.component.html',
  styleUrls: ['./room-management.component.css']
})
export class RoomManagementComponent implements OnInit {
  rooms: Room[] = [
    { roomNo: '101', type: 'Deluxe', status: 'Available', price: 150 },
    { roomNo: '102', type: 'Standard', status: 'Occupied', price: 100 },
    { roomNo: '201', type: 'Suite', status: 'Available', price: 250 },
  ];

  newRoom: Room = { roomNo: '', type: '', status: 'Available', price: 0 };

  constructor() {}

  ngOnInit(): void {
    // In a real application, you would fetch rooms from a backend service here.
    console.log('RoomManagementComponent initialized. Rooms:', this.rooms);
  }

  addRoom(): void {
    // Basic validation
    if (!this.newRoom.roomNo || !this.newRoom.type || this.newRoom.price <= 0) {
      alert('Please fill in all room details and ensure price is greater than 0.');
      return;
    }

    // Check if room number already exists (simple client-side check)
    if (this.rooms.some(room => room.roomNo === this.newRoom.roomNo)) {
      alert(`Room number ${this.newRoom.roomNo} already exists. Please use a different number.`);
      return;
    }

    this.rooms.push({ ...this.newRoom }); // Add a copy of the newRoom object
    console.log('Room added:', this.newRoom);
    // In a real app, send newRoom data to your backend API
    // this.roomService.addRoom(this.newRoom).subscribe(response => { /* handle response */ });

    // Reset form for next entry
    this.newRoom = { roomNo: '', type: '', status: 'Available', price: 0 };
  }

  editRoom(roomNo: string): void {
    console.log('Edit Room:', roomNo);
    // In a real app, you would:
    // 1. Fetch the specific room data by roomNo (e.g., from an API or the local 'rooms' array).
    // 2. Populate a separate edit form or a modal with this room's data.
    // 3. Allow the user to make changes and save them.
    // For now, this is a console log.
    alert(`Simulating edit for Room No: ${roomNo}. In a real app, an edit form would appear.`);
  }

  deleteRoom(roomNo: string): void {
    if (confirm(`Are you sure you want to delete room ${roomNo}? This action cannot be undone.`)) {
      this.rooms = this.rooms.filter(room => room.roomNo !== roomNo);
      console.log('Room deleted:', roomNo);
      // In a real app, send delete request to your backend API
      // this.roomService.deleteRoom(roomNo).subscribe(response => { /* handle response */ });
    }
  }
}
