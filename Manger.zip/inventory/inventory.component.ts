// import { Component } from '@angular/core';

// @Component({
//   selector: 'app-inventory',
//   imports: [],
//   templateUrl: './inventory.component.html',
//   styleUrl: './inventory.component.css'
// })
// export class InventoryComponent {

// }
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common'; // For NgIf, NgFor
import { FormsModule } from '@angular/forms'; // For [(ngModel)]

interface InventoryItem {
  itemName: string;
  category: string;
  quantity: number;
  roomId?: string; // Optional: for room-specific items
}

@Component({
  selector: 'app-inventory-management',
  standalone: true,
  imports: [CommonModule, FormsModule], // Ensure CommonModule and FormsModule are imported
  templateUrl: './inventory-management.component.html',
  styleUrls: ['./inventory-management.component.css']
})
export class InventoryManagementComponent implements OnInit {
  inventoryList: InventoryItem[] = [
    { itemName: 'Towels (Large)', category: 'Linen', quantity: 150, roomId: '' },
    { itemName: 'Shampoo Bottles', category: 'Toiletries', quantity: 300, roomId: '' },
    { itemName: 'Mini Bar Soda', category: 'Food & Beverage', quantity: 20, roomId: '101' },
    { itemName: 'Pillows (Spare)', category: 'Linen', quantity: 50, roomId: '' },
  ];

  newItem: InventoryItem = { itemName: '', category: '', quantity: 0, roomId: '' };

  constructor() {}

  ngOnInit(): void {
    // In a real application, you would fetch inventory items from a backend service here.
    console.log('InventoryManagementComponent initialized. Inventory:', this.inventoryList);
  }

  addItem(): void {
    // Basic validation for required fields
    if (!this.newItem.itemName || !this.newItem.category || this.newItem.quantity <= 0) {
      alert('Please fill in Item Name, Category, and ensure Quantity is greater than 0.');
      return;
    }

    // Check if item name already exists (simple client-side check)
    // You might want a more sophisticated check that includes category/roomId
    if (this.inventoryList.some(item => item.itemName === this.newItem.itemName && item.category === this.newItem.category)) {
      alert(`An inventory item '${this.newItem.itemName}' in category '${this.newItem.category}' already exists.`);
      return;
    }

    this.inventoryList.push({ ...this.newItem }); // Add a copy of the newItem object
    console.log('Inventory item added:', this.newItem);
    // In a real app, send newItem data to your backend API (e.g., this.inventoryService.addItem(this.newItem))

    // Reset form for next entry
    this.newItem = { itemName: '', category: '', quantity: 0, roomId: '' };
  }

  editItem(itemName: string): void {
    console.log('Edit Item:', itemName);
    // In a real app, you would:
    // 1. Fetch the specific item data by itemName (e.g., from an API or the local 'inventoryList' array).
    // 2. Populate a separate edit form or a modal with this item's data.
    // 3. Allow the user to make changes and save them.
    alert(`Simulating edit for Item: ${itemName}. In a real app, an edit form would appear.`);
  }

  deleteItem(itemName: string): void {
    if (confirm(`Are you sure you want to delete '${itemName}' from inventory? This action cannot be undone.`)) {
      this.inventoryList = this.inventoryList.filter(item => item.itemName !== itemName);
      console.log('Item deleted:', itemName);
      // In a real app, send delete request to your backend API (e.g., this.inventoryService.deleteItem(itemName))
    }
  }
}
