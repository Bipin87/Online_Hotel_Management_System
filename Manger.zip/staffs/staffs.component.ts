// import { Component } from '@angular/core';

// @Component({
//   selector: 'app-staffs',
//   imports: [],
//   templateUrl: './staffs.component.html',
//   styleUrl: './staffs.component.css'
// })
// export class StaffsComponent {

// }
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common'; // For NgIf, NgFor, CurrencyPipe (implicitly for number pipe)
import { FormsModule } from '@angular/forms'; // For [(ngModel)]

interface Staff {
  id: string;
  fullName: string;
  email: string;
  role: string; // e.g., Receptionist, Housekeeping, Manager
  salary: number;
  address: string;
  age: number;
  occupation: string; // Detailed occupation, e.g., "Senior Receptionist", "Head Chef"
  idProof: string; // e.g., "Passport", "Driver's License"
  idProofNumber: string;
  phoneNumber: string;
  joiningDate: string; // YYYY-MM-DD format for input[type="date"]
  department: string; // e.g., "Front Desk", "Kitchen", "Housekeeping"
}

@Component({
  selector: 'app-staff-management',
  standalone: true,
  imports: [CommonModule, FormsModule], // Ensure CommonModule and FormsModule are imported
  templateUrl: './staff-management.component.html',
  styleUrls: ['./staff-management.component.css']
})
export class StaffManagementComponent implements OnInit {
  staffList: Staff[] = [
    {
      id: 'S001',
      fullName: 'Alice Johnson',
      email: 'alice@hotel.com',
      role: 'Receptionist',
      salary: 45000,
      address: '123 Main St, Anytown',
      age: 28,
      occupation: 'Front Desk Officer',
      idProof: 'National ID',
      idProofNumber: 'NID-56789',
      phoneNumber: '+1-555-123-4567',
      joiningDate: '2022-03-15',
      department: 'Front Desk'
    },
    {
      id: 'S002',
      fullName: 'Bob Williams',
      email: 'bob@hotel.com',
      role: 'Housekeeping',
      salary: 32000,
      address: '456 Oak Ave, Somewhere',
      age: 35,
      occupation: 'Head Housekeeper',
      idProof: 'Driver\'s License',
      idProofNumber: 'DL-98765',
      phoneNumber: '+1-555-987-6543',
      joiningDate: '2021-07-01',
      department: 'Housekeeping'
    },
    {
      id: 'S003',
      fullName: 'Charlie Davis',
      email: 'charlie@hotel.com',
      role: 'Chef',
      salary: 60000,
      address: '789 Pine Rd, Nowhere',
      age: 42,
      occupation: 'Executive Chef',
      idProof: 'Passport',
      idProofNumber: 'PAS-11223',
      phoneNumber: '+1-555-222-3333',
      joiningDate: '2020-01-20',
      department: 'Kitchen'
    }
  ];

  newStaff: Staff = {
    id: '',
    fullName: '',
    email: '',
    role: '',
    salary: 0,
    address: '',
    age: 0,
    occupation: '',
    idProof: '',
    idProofNumber: '',
    phoneNumber: '',
    joiningDate: '',
    department: ''
  };

  constructor() {}

  ngOnInit(): void {
    // In a real application, you would fetch staff from a backend service here.
    console.log('StaffManagementComponent initialized. Staff:', this.staffList);
  }

  addStaff(): void {
    // Basic validation for required fields
    if (!this.newStaff.fullName || !this.newStaff.email || this.newStaff.salary <= 0 ||
        !this.newStaff.address || this.newStaff.age < 18 || !this.newStaff.occupation ||
        !this.newStaff.idProof || !this.newStaff.idProofNumber || !this.newStaff.phoneNumber ||
        !this.newStaff.joiningDate || !this.newStaff.department) {
      alert('Please fill in all required staff details correctly.');
      return;
    }

    // Basic email format validation
    if (!this.newStaff.email.includes('@') || !this.newStaff.email.includes('.')) {
      alert('Please enter a valid email address.');
      return;
    }

    // Check if email already exists (simple client-side check)
    if (this.staffList.some(staff => staff.email === this.newStaff.email)) {
      alert(`A staff member with email ${this.newStaff.email} already exists.`);
      return;
    }

    // Generate a simple ID for simulation; in a real app, backend would assign UUID
    const newId = 'S' + (this.staffList.length + 1).toString().padStart(3, '0');
    this.newStaff.id = newId;

    this.staffList.push({ ...this.newStaff }); // Add a copy of the newStaff object
    console.log('Staff added:', this.newStaff);
    // In a real app, send newStaff data to your backend API (e.g., this.staffService.addStaff(this.newStaff))

    // Reset form for next entry
    this.newStaff = {
      id: '',
      fullName: '',
      email: '',
      role: '',
      salary: 0,
      address: '',
      age: 0,
      occupation: '',
      idProof: '',
      idProofNumber: '',
      phoneNumber: '',
      joiningDate: '',
      department: ''
    };
  }

  editStaff(staffId: string): void {
    console.log('Edit Staff:', staffId);
    // In a real app, you would:
    // 1. Fetch the specific staff member data by staffId (e.g., from an API or the local 'staffList' array).
    // 2. Populate a separate edit form or a modal with this staff member's data.
    // 3. Allow the user to make changes and save them.
    alert(`Simulating edit for Staff ID: ${staffId}. In a real app, an edit form would appear with all fields.`);
  }

  deleteStaff(staffId: string): void {
    if (confirm(`Are you sure you want to delete staff member ${staffId}? This action cannot be undone.`)) {
      this.staffList = this.staffList.filter(staff => staff.id !== staffId);
      console.log('Staff deleted:', staffId);
      // In a real app, send delete request to your backend API (e.g., this.staffService.deleteStaff(staffId))
    }
  }
}
