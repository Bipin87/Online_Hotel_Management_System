// import { Injectable } from '@angular/core';

// @Injectable({
//   providedIn: 'root'
// })
// export class AuthService {

//   constructor() { }
// }
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { delay, tap } from 'rxjs/operators';

interface User {
  id: number;
  username: string;
  email: string;
  password?: string; // Password should not be stored in frontend User object normally
  role: 'admin' | 'manager' | 'receptionist';
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private currentUserSubject: BehaviorSubject<User | null>;
  public currentUser: Observable<User | null>;

  // Simulate registered users (replace with backend API calls)
  private mockUsers: User[] = [
    { id: 1, username: 'adminuser', email: 'admin@hotel.com', password: 'adminpassword', role: 'admin' },
    { id: 2, username: 'manager1', email: 'manager@hotel.com', password: 'managerpassword', role: 'manager' },
    { id: 3, username: 'receptionist1', email: 'receptionist@hotel.com', password: 'receptionistpassword', role: 'receptionist' },
  ];

  constructor() {
    // Initialize current user from local storage or null
    const storedUser = localStorage.getItem('currentUser');
    this.currentUserSubject = new BehaviorSubject<User | null>(storedUser ? JSON.parse(storedUser) : null);
    this.currentUser = this.currentUserSubject.asObservable();
  }

  public get currentUserValue(): User | null {
    return this.currentUserSubject.value;
  }

  public get isLoggedIn$(): Observable<boolean> {
    return this.currentUserSubject.asObservable().pipe(
      tap(user => console.log('AuthService: User changed', user)),
      // Map user object to boolean isLoggedIn
      obs => new Observable(subscriber => {
        obs.subscribe(user => subscriber.next(!!user));
      })
    );
  }

  checkLoginStatus(): boolean {
    return !!this.currentUserSubject.value;
  }

  async login(email: string, password: string): Promise<boolean> {
    // Simulate API call with a delay
    await new Promise(resolve => setTimeout(resolve, 500));

    const foundUser = this.mockUsers.find(
      user => user.email === email && user.password === password
    );

    if (foundUser) {
      // In a real app, store token from backend response
      const userWithoutPassword = { ...foundUser, password: undefined }; // Don't store password
      localStorage.setItem('currentUser', JSON.stringify(userWithoutPassword));
      this.currentUserSubject.next(userWithoutPassword);
      return true;
    }
    return false;
  }

  async register(user: { username: string, email: string, password: string, role: string }): Promise<boolean> {
    // Simulate API call with a delay
    await new Promise(resolve => setTimeout(resolve, 500));

    const userExists = this.mockUsers.some(u => u.email === user.email);
    if (userExists) {
      return false; // User already exists
    }

    const newUser: User = {
      id: Date.now(),
      username: user.username,
      email: user.email,
      password: user.password,
      role: user.role as 'admin' | 'manager' | 'receptionist'
    };
    this.mockUsers.push(newUser);
    console.log('New user registered (simulated):', newUser);
    return true;
  }

  logout(): void {
    localStorage.removeItem('currentUser');
    this.currentUserSubject.next(null);
  }
}