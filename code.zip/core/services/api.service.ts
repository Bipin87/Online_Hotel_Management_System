// import { Injectable } from '@angular/core';

// @Injectable({
//   providedIn: 'root'
// })
// export class ApiService {

//   constructor() { }
// }
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { AuthService } from './auth.service'; // To get auth token

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private apiUrl = '/api'; // Your backend API base URL

  constructor(private http: HttpClient, private authService: AuthService) {}

  private getHeaders(): HttpHeaders {
    let headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    const currentUser = this.authService.currentUserValue;
    // In a real app, you'd get the actual token here (e.g., currentUser.token)
    // if (currentUser && currentUser.token) {
    //   headers = headers.set('Authorization', `Bearer ${currentUser.token}`);
    // }
    return headers;
  }

  private formatErrors(error: any): Observable<never> {
    console.error('API Error:', error);
    // You might want more sophisticated error handling, e.g.,
    // logging to a service, showing user-friendly messages.
    return throwError(() => new Error('An API error occurred.'));
  }

  get<T>(path: string): Observable<T> {
    return this.http.get<T>(`${this.apiUrl}${path}`, { headers: this.getHeaders() })
      .pipe(catchError(this.formatErrors));
  }

  post<T>(path: string, body: Object = {}): Observable<T> {
    return this.http.post<T>(`${this.apiUrl}${path}`, JSON.stringify(body), { headers: this.getHeaders() })
      .pipe(catchError(this.formatErrors));
  }

  put<T>(path: string, body: Object = {}): Observable<T> {
    return this.http.put<T>(`${this.apiUrl}${path}`, JSON.stringify(body), { headers: this.getHeaders() })
      .pipe(catchError(this.formatErrors));
  }

  delete<T>(path: string): Observable<T> {
    return this.http.delete<T>(`${this.apiUrl}${path}`, { headers: this.getHeaders() })
      .pipe(catchError(this.formatErrors));
  }
}