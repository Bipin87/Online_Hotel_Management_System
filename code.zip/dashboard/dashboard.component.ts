// import { Component } from '@angular/core';

// @Component({
//   selector: 'app-dashboard',
//   imports: [],
//   templateUrl: './dashboard.component.html',
//   styleUrl: './dashboard.component.css'
// })
// export class DashboardComponent {

// }
import { Component, OnInit } from '@angular/core';
import { NgIf } from '@angular/common'; // Import NgIf
import { AuthService } from '../core/services/auth.service'; // Assuming AuthService
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component'; // Import child components
import { ManagerDashboardComponent } from './manager-dashboard/manager-dashboard.component';
import { ReceptionistDashboardComponent } from './receptionist-dashboard/receptionist-dashboard.component';

@Component({
  selector: 'app-dashboard',
  standalone: true, // Mark as standalone
  imports: [NgIf, AdminDashboardComponent, ManagerDashboardComponent, ReceptionistDashboardComponent], // Import necessary modules and components
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  dashboardTitle: string = 'Welcome to Your Dashboard!';
  dashboardWelcomeMessage: string = '';
  currentRole: string | null = null;

  constructor(private authService: AuthService) {}

  ngOnInit(): void {
    const currentUser = this.authService.currentUserValue;
    if (currentUser) {
      this.currentRole = currentUser.role;
      this.updateDashboardContent(currentUser.role, currentUser.username);
    } else {
      // Handle case where user is not logged in (e.g., redirect to login)
      // This should ideally be handled by an Angular Auth Guard
    }
  }

  private updateDashboardContent(role: string, username: string): void {
    if (role === 'admin') {
      this.dashboardTitle = 'Admin Dashboard';
      this.dashboardWelcomeMessage = `Welcome, Administrator ${username}!`;
    } else if (role === 'manager') {
      this.dashboardTitle = 'Manager Dashboard';
      this.dashboardWelcomeMessage = `Welcome, Manager ${username}!`;
    } else if (role === 'receptionist') {
      this.dashboardTitle = 'Receptionist Dashboard';
      this.dashboardWelcomeMessage = `Welcome, Receptionist ${username}!`;
    } else {
      this.dashboardTitle = 'Dashboard';
      this.dashboardWelcomeMessage = `Welcome, ${username}! Your role is not recognized.`;
    }
  }

  // This method would be more complex in a real Angular app, potentially involving
  // child routes or NgSwitch for detailed section display within each role's dashboard.
  showDashboardSection(sectionId: string): void {
    console.log(`Navigating to section: ${sectionId}`);
    // In a real app, this might navigate to a child route or toggle a specific component visibility
    // For now, this is just a placeholder action.
  }
}