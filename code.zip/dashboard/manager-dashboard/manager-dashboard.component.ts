// import { Component } from '@angular/core';

// @Component({
//   selector: 'app-manager-dashboard',
//   imports: [],
//   templateUrl: './manager-dashboard.component.html',
//   styleUrl: './manager-dashboard.component.css'
// })
// export class ManagerDashboardComponent {

// }
import { Component } from '@angular/core';

@Component({
  selector: 'app-manager-dashboard',
  standalone: true, // Mark as standalone
  imports: [], // No specific Angular modules needed here yet
  templateUrl: './manager-dashboard.component.html',
  styleUrls: ['./manager-dashboard.component.css']
})
export class ManagerDashboardComponent {
  manageRooms(): void {
    console.log('Navigate to Room Management');
    // In a real app: this.router.navigate(['/dashboard/manager/rooms']);
  }
  manageStaff(): void {
    console.log('Navigate to Staff Management');
    // In a real app: this.router.navigate(['/dashboard/manager/staff']);
  }
  manageInventory(): void {
    console.log('Navigate to Inventory Management');
    // In a real app: this.router.navigate(['/dashboard/manager/inventory']);
  }
}