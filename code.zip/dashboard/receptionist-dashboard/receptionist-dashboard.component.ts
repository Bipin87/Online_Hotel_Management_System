import { Component } from '@angular/core';

@Component({
  selector: 'app-receptionist-dashboard',
  imports: [],
  templateUrl: './receptionist-dashboard.component.html',
  styleUrl: './receptionist-dashboard.component.css'
})
export class ReceptionistDashboardComponent {

}
