// import { Component } from '@angular/core';
// import { RouterOutlet } from '@angular/router';

// @Component({
//   selector: 'app-root',
//   imports: [RouterOutlet],
//   templateUrl: './app.component.html',
//   styleUrl: './app.component.css'
// })
// export class AppComponent {
//   title = 'hotel-management';
// }
import { Component, OnInit } from '@angular/core';
import { RouterOutlet, RouterLink, RouterLinkActive, Router } from '@angular/router'; // Import RouterOutlet, RouterLink, RouterLinkActive
import { NgIf } from '@angular/common'; // Import NgIf for conditional rendering
import { AuthService } from './core/services/auth.service'; // Assuming an AuthService

@Component({
  selector: 'app-root',
  standalone: true, // Mark as standalone
  imports: [RouterOutlet, RouterLink, RouterLinkActive, NgIf], // Import necessary modules
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'hotel-management-system';
  isLoggedIn: boolean = false;

  constructor(private authService: AuthService, private router: Router) {}

  ngOnInit(): void {
    // Subscribe to auth service to update login status
    this.authService.isLoggedIn$.subscribe(loggedIn => {
      this.isLoggedIn = loggedIn;
    });

    // Check initial login state (e.g., from local storage on app load)
    this.isLoggedIn = this.authService.checkLoginStatus();
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/home']); // Redirect to home after logout
  }
}