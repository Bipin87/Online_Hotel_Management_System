// import { Routes } from '@angular/router';

// export const routes: Routes = [];
import { Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './auth/login/login.component';
import { RegisterComponent } from './auth/register/register.component';
import { DashboardComponent } from './dashboard/dashboard.component';
// Import auth guards when you implement them
// import { AuthGuard } from './core/guards/auth.guard'; // Example AuthGuard import

export const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'home', component: HomeComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  {
    path: 'dashboard',
    component: DashboardComponent,
    // canActivate: [AuthGuard] // Protect dashboard route with a standalone AuthGuard
    // You'd add child routes for each role's specific pages here too
    // children: [
    //   { path: 'admin', component: AdminDashboardComponent, canActivate: [AuthGuard], data: { roles: ['admin'] } },
    //   { path: 'manager', component: ManagerDashboardComponent, canActivate: [AuthGuard], data: { roles: ['manager'] } },
    //   { path: 'receptionist', component: ReceptionistDashboardComponent, canActivate: [AuthGuard], data: { roles: ['receptionist'] } },
    // ]
  },
  { path: '**', redirectTo: '/home' } // Wildcard route for a 404 page or redirect
];