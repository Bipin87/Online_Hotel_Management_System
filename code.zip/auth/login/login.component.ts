// import { Component } from '@angular/core';

// @Component({
//   selector: 'app-login',
//   imports: [],
//   templateUrl: './login.component.html',
//   styleUrl: './login.component.css'
// })
// export class LoginComponent {

// }
import { Component } from '@angular/core';
import { RouterLink, Router } from '@angular/router'; // Import RouterLink
import { FormsModule } from '@angular/forms'; // Import FormsModule for ngModel
import { NgIf } from '@angular/common'; // Import NgIf for conditional rendering
import { AuthService } from '../../core/services/auth.service'; // Assuming AuthService

@Component({
  selector: 'app-login',
  standalone: true, // Mark as standalone
  imports: [RouterLink, FormsModule, NgIf], // Import necessary modules
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'] // Refers to the shared form styles
})
export class LoginComponent {
  email = '';
  password = '';
  loginMessage = '';
  messageColor = '';

  constructor(private authService: AuthService, private router: Router) {}

  async loginUser(): Promise<void> {
    if (!this.email || !this.password) {
      this.loginMessage = 'Please enter both email and password.';
      this.messageColor = '#e74c3c';
      return;
    }

    try {
      // Call AuthService to simulate login
      const success = await this.authService.login(this.email, this.password);

      if (success) {
        this.loginMessage = `Login successful! Welcome, ${this.authService.currentUserValue?.username}.`;
        this.messageColor = '#27ae60';
        setTimeout(() => this.router.navigate(['/dashboard']), 1000);
      } else {
        this.loginMessage = 'Invalid email or password.';
        this.messageColor = '#e74c3c';
      }
    } catch (error) {
      console.error('Login error:', error);
      this.loginMessage = 'Login failed. Please try again later.';
      this.messageColor = '#e74c3c';
    }
  }
}