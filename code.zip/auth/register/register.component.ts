// import { Component } from '@angular/core';

// @Component({
//   selector: 'app-register',
//   imports: [],
//   templateUrl: './register.component.html',
//   styleUrl: './register.component.css'
// })
// export class RegisterComponent {

// }
import { Component } from '@angular/core';
import { RouterLink, Router } from '@angular/router'; // Import RouterLink
import { FormsModule } from '@angular/forms'; // Import FormsModule for ngModel
import { NgIf } from '@angular/common'; // Import NgIf for conditional rendering
import { AuthService } from '../../core/services/auth.service'; // Assuming AuthService

@Component({
  selector: 'app-register',
  standalone: true, // Mark as standalone
  imports: [RouterLink, FormsModule, NgIf], // Import necessary modules
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  username = '';
  email = '';
  password = '';
  role = '';
  registerMessage = '';
  messageColor = '';

  constructor(private authService: AuthService, private router: Router) {}

  async registerUser(): Promise<void> {
    if (!this.username || !this.email || !this.password || !this.role) {
      this.registerMessage = 'Please fill in all fields.';
      this.messageColor = '#e74c3c';
      return;
    }

    if (!this.email.includes('@') || !this.email.includes('.')) {
      this.registerMessage = 'Please enter a valid email address.';
      this.messageColor = '#e74c3c';
      return;
    }

    try {
      // Call AuthService to simulate registration
      const success = await this.authService.register({
        username: this.username,
        email: this.email,
        password: this.password,
        role: this.role
      });

      if (success) {
        this.registerMessage = 'Registration successful! You can now log in.';
        this.messageColor = '#27ae60';
        // Clear form
        this.username = '';
        this.email = '';
        this.password = '';
        this.role = '';
        setTimeout(() => this.router.navigate(['/login']), 2000);
      } else {
        this.registerMessage = 'User with this email already exists.';
        this.messageColor = '#e74c3c';
      }
    } catch (error) {
      console.error('Registration error:', error);
      this.registerMessage = 'Registration failed. Please try again later.';
      this.messageColor = '#e74c3c';
    }
  }
}